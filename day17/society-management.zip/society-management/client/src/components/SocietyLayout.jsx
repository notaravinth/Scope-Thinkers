import { NavLink, Outlet, useNavigate } from "react-router-dom";
import useSocietyAuthStore from "../store/societyAuthStore";

const navItems = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/complaints", label: "Complaints" },
  { to: "/visitors", label: "Visitors" },
  { to: "/announcements", label: "Announcements" },
  { to: "/payments", label: "Payments" },
  { to: "/properties", label: "Properties" },
];

const SocietyLayout = () => {
  const { societyUser, logout } = useSocietyAuthStore();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const isManager = societyUser?.role === "manager";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 lg:flex">
      <aside className="w-full border-b border-white/10 bg-slate-900/80 p-5 backdrop-blur lg:min-h-screen lg:w-64 lg:border-b-0 lg:border-r">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-cyan-400">
            Society
          </p>
          <h1 className="mt-1 text-2xl font-bold">NestHub</h1>
        </div>

        <nav className="flex gap-2 overflow-x-auto lg:block">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `mb-2 block whitespace-nowrap rounded-xl px-4 py-3 text-sm transition ${
                  isActive
                    ? "bg-cyan-400 font-semibold text-slate-950"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}

          {isManager && (
            <NavLink
              to="/users"
              className={({ isActive }) =>
                `mb-2 block whitespace-nowrap rounded-xl px-4 py-3 text-sm transition ${
                  isActive
                    ? "bg-cyan-400 font-semibold text-slate-950"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`
              }
            >
              Users
            </NavLink>
          )}
        </nav>

        <div className="mt-8 rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="text-sm font-semibold">{societyUser?.name}</p>
          <p className="mt-1 text-xs capitalize text-slate-400">
            {societyUser?.role}
          </p>

          <button
            onClick={handleLogout}
            className="mt-4 w-full rounded-xl border border-white/10 px-3 py-2 text-sm text-slate-300 hover:bg-white/10"
          >
            Logout
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-7xl p-5 md:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default SocietyLayout;
