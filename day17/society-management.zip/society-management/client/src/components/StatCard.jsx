const StatCard = ({ label, value, hint }) => (
  <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
    <p className="text-sm text-slate-400">{label}</p>
    <p className="mt-2 text-3xl font-bold">{value}</p>
    {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
  </div>
);

export default StatCard;
