import { useState } from "react";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../config/firebase";

const Signup = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData((current) => ({
      ...current,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const credential = await createUserWithEmailAndPassword(
        auth,
        formData.email,
        formData.password
      );

      await updateProfile(credential.user, {
        displayName: formData.name,
      });

      const token = await credential.user.getIdToken();

      const response = await fetch(
        `${import.meta.env.VITE_API_URL || "http://localhost:5000/api"}/society-users`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: formData.name,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not create society profile");
      }

      navigate("/dashboard");
    } catch (error) {
      console.error(error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-10 text-slate-100">
      <div className="mx-auto grid min-h-[80vh] max-w-5xl items-center gap-10 lg:grid-cols-2">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-400">
            NestHub
          </p>
          <h1 className="mt-4 text-5xl font-black tracking-tight">
            Your society,
            <br />
            in one place.
          </h1>
          <p className="mt-5 max-w-lg text-slate-400">
            Manage complaints, visitors, announcements and maintenance
            payments with role-based access.
          </p>
        </div>

        <form
          onSubmit={handleSignup}
          className="rounded-3xl border border-white/10 bg-white/5 p-7 shadow-2xl backdrop-blur"
        >
          <h2 className="text-2xl font-bold">Create account</h2>
          <p className="mt-1 text-sm text-slate-400">
            New accounts start as residents.
          </p>

          <div className="mt-6 space-y-4">
            <input
              name="name"
              placeholder="Full name"
              value={formData.name}
              onChange={handleChange}
              required
              className="input"
            />
            <input
              name="email"
              type="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
              className="input"
            />
            <input
              name="password"
              type="password"
              placeholder="Password"
              minLength={6}
              value={formData.password}
              onChange={handleChange}
              required
              className="input"
            />
          </div>

          {error && <p className="error-box mt-4">{error}</p>}

          <button disabled={loading} className="primary-btn mt-5">
            {loading ? "Creating..." : "Create account"}
          </button>

          <p className="mt-5 text-center text-sm text-slate-400">
            Already registered?{" "}
            <Link to="/login" className="font-semibold text-cyan-400">
              Login
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Signup;
