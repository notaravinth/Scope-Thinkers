import { useEffect, useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { auth } from "../config/firebase";
import useSocietyAuthStore from "../store/societyAuthStore";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { firebaseUser, societyUser } = useSocietyAuthStore();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (firebaseUser && societyUser) {
      navigate("/dashboard", { replace: true });
    }
  }, [firebaseUser, societyUser, navigate]);

  const handleChange = (e) => {
    setFormData((current) => ({
      ...current,
      [e.target.name]: e.target.value,
    }));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await signInWithEmailAndPassword(
        auth,
        formData.email,
        formData.password
      );

      const destination = location.state?.from || "/dashboard";
      navigate(destination, { replace: true });
    } catch (error) {
      console.error(error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-10 text-slate-100">
      <div className="mx-auto flex min-h-[80vh] max-w-md items-center">
        <form
          onSubmit={handleLogin}
          className="w-full rounded-3xl border border-white/10 bg-white/5 p-7 shadow-2xl"
        >
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-400">
            NestHub
          </p>
          <h1 className="mt-3 text-3xl font-black">Welcome back</h1>
          <p className="mt-1 text-slate-400">
            Sign in to your society account.
          </p>

          <div className="mt-7 space-y-4">
            <input
              name="email"
              type="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
              className="input"
            />
            <input
              name="password"
              type="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              className="input"
            />
          </div>

          {error && <p className="error-box mt-4">{error}</p>}

          <button disabled={loading} className="primary-btn mt-5">
            {loading ? "Signing in..." : "Sign in"}
          </button>

          <p className="mt-5 text-center text-sm text-slate-400">
            No account?{" "}
            <Link to="/signup" className="font-semibold text-cyan-400">
              Create one
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
