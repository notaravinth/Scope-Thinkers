import { useEffect, useState } from "react";
import { apiFetch } from "../services/api";
import useSocietyAuthStore from "../store/societyAuthStore";
import StatCard from "../components/StatCard";

const Dashboard = () => {
  const { societyUser } = useSocietyAuthStore();
  const [stats, setStats] = useState({
    complaints: 0,
    visitors: 0,
    announcements: 0,
    payments: 0,
  });

  useEffect(() => {
    const loadStats = async () => {
      try {
        const [complaints, visitors, announcements, payments] =
          await Promise.all([
            apiFetch("/society-complaints"),
            apiFetch("/society-visitors"),
            apiFetch("/society-announcements"),
            apiFetch("/society-payments"),
          ]);

        setStats({
          complaints: complaints.complaints.length,
          visitors: visitors.visitors.length,
          announcements: announcements.announcements.length,
          payments: payments.payments.filter((p) => p.status !== "paid").length,
        });
      } catch (error) {
        console.error(error);
      }
    };

    loadStats();
  }, []);

  return (
    <div>
      <div className="mb-8">
        <p className="text-sm text-cyan-400">Good to see you</p>
        <h1 className="mt-1 text-4xl font-black">
          Hi, {societyUser?.name}
        </h1>
        <p className="mt-2 text-slate-400">
          Here&apos;s what&apos;s happening in your society.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Complaints"
          value={stats.complaints}
          hint="Visible to your role"
        />
        <StatCard
          label="Visitors"
          value={stats.visitors}
          hint="Recent visitor records"
        />
        <StatCard
          label="Announcements"
          value={stats.announcements}
          hint="Society updates"
        />
        <StatCard
          label="Pending bills"
          value={stats.payments}
          hint="Payments not marked paid"
        />
      </div>

      <div className="mt-8 rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-400/10 to-white/5 p-7">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-cyan-400">
          Your access level
        </p>
        <h2 className="mt-2 text-3xl font-bold capitalize">
          {societyUser?.role}
        </h2>
        <p className="mt-2 max-w-2xl text-slate-400">
          Your role controls which actions the backend allows. The UI is only
          a convenience; every protected API route also checks permissions.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
