import { useEffect, useRef, useState } from "react";
import {
  File,
  Image,
  Paperclip,
  Send,
  Smile,
  X,
} from "lucide-react";

import { sendWebSocketMessage } from "../../services/webSocketService";
import {
  formatFileSize,
  isImageFile,
  MAX_ATTACHMENT_SIZE,
  uploadChatAttachment,
} from "../../services/fileService";

const MessageInput = ({ chat, currentUserId }) => {
  const [message, setMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [sending, setSending] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");

  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);

  const receiverId = chat?.otherUser?.uid;

  useEffect(() => {
    if (!selectedFile || !isImageFile(selectedFile)) {
      setPreviewUrl("");
      return undefined;
    }

    const url = URL.createObjectURL(selectedFile);
    setPreviewUrl(url);

    return () => {
      URL.revokeObjectURL(url);
    };
  }, [selectedFile]);

  const chooseFile = (file) => {
    setError("");

    if (!file) return;

    if (file.size > MAX_ATTACHMENT_SIZE) {
      setError("Files must be 25 MB or smaller.");
      return;
    }

    setSelectedFile(file);
  };

  const handleFileChange = (event) => {
    const file = event.target.files?.[0];

    chooseFile(file);

    event.target.value = "";
  };

  const removeSelectedFile = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    setError("");
  };

  const sendTextMessage = async (trimmedMessage) => {
    await sendWebSocketMessage({
      type: "send_message",
      chatId: chat.id,
      receiverId,
      content: trimmedMessage,
    });
  };

  const sendAttachment = async (file) => {
    setUploadProgress(0);

    const attachment = await uploadChatAttachment({
      file,
      chatId: chat.id,
      userId: currentUserId,
      onProgress: setUploadProgress,
    });

    await sendWebSocketMessage({
      type: "send_message",
      chatId: chat.id,
      receiverId,
      content: message.trim(),
      messageType: isImageFile(file) ? "image" : "file",
      attachment,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const trimmedMessage = message.trim();

    if (
      (!trimmedMessage && !selectedFile) ||
      !chat?.id ||
      !currentUserId ||
      !receiverId ||
      sending
    ) {
      return;
    }

    try {
      setSending(true);
      setError("");

      if (selectedFile) {
        await sendAttachment(selectedFile);
      } else {
        await sendTextMessage(trimmedMessage);
      }

      setMessage("");
      setSelectedFile(null);
      setUploadProgress(0);
    } catch (error) {
      console.error("Failed to send message:", error);
      setError(error?.message || "Failed to send message.");
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSubmit(event);
    }
  };

  return (
    <div className="border-t border-[#C2956E]/30 bg-[#2B2129] p-4">
      {error && (
        <div className="mb-3 rounded-xl border border-[#C2956E]/40 bg-[#E5D1B8]/5 px-3 py-2 text-xs text-[#DD8E58]">
          {error}
        </div>
      )}

      {selectedFile && (
        <div className="mb-3 flex items-center gap-3 rounded-2xl border border-[#C2956E]/30 bg-[#E5D1B8]/5 p-3">
          {isImageFile(selectedFile) ? (
            <img
              src={previewUrl}
              alt="Selected preview"
              className="h-14 w-14 rounded-xl object-cover"
            />
          ) : (
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-[#708A81] text-[#E5D1B8]">
              <File size={22} />
            </div>
          )}

          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-[#E5D1B8]">
              {selectedFile.name}
            </p>
            <p className="mt-1 text-xs text-[#C2956E]">
              {formatFileSize(selectedFile.size)}
              {sending && ` · Uploading ${uploadProgress}%`}
            </p>

            {sending && (
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#2B2129]">
                <div
                  className="h-full rounded-full bg-[#DD8E58] transition-all"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            )}
          </div>

          {!sending && (
            <button
              type="button"
              onClick={removeSelectedFile}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[#C2956E] transition hover:bg-[#C2956E] hover:text-[#2B2129]"
              aria-label="Remove attachment"
            >
              <X size={17} />
            </button>
          )}
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileChange}
      />

      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      <form onSubmit={handleSubmit} className="flex items-end gap-3">
        <button
          type="button"
          disabled={sending}
          onClick={() => fileInputRef.current?.click()}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#C2956E]/30 text-[#C2956E] transition hover:border-[#DD8E58] hover:text-[#DD8E58] disabled:cursor-not-allowed disabled:opacity-50"
          aria-label="Attach a file"
        >
          <Paperclip size={19} />
        </button>

        <button
          type="button"
          disabled={sending}
          onClick={() => imageInputRef.current?.click()}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#C2956E]/30 text-[#C2956E] transition hover:border-[#DD8E58] hover:text-[#DD8E58] disabled:cursor-not-allowed disabled:opacity-50"
          aria-label="Attach an image"
        >
          <Image size={19} />
        </button>

        <div className="relative flex-1">
          <textarea
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            onKeyDown={handleKeyDown}
            disabled={sending}
            rows={1}
            placeholder={selectedFile ? "Add a caption..." : "Write a message..."}
            className="max-h-32 min-h-12 w-full resize-none rounded-2xl border border-[#C2956E]/30 bg-[#E5D1B8]/5 px-4 py-3 pr-12 text-sm text-[#E5D1B8] outline-none transition placeholder:text-[#C2956E] focus:border-[#DD8E58] disabled:opacity-50"
          />

          <button
            type="button"
            disabled={sending}
            className="absolute bottom-0 right-0 flex h-12 w-12 items-center justify-center text-[#C2956E] transition hover:text-[#DD8E58] disabled:opacity-50"
            aria-label="Emoji"
          >
            <Smile size={19} />
          </button>
        </div>

        <button
          type="submit"
          disabled={sending || (!message.trim() && !selectedFile)}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#DD8E58] text-[#2B2129] transition hover:bg-[#C2956E] disabled:cursor-not-allowed disabled:opacity-40"
          aria-label="Send message"
        >
          <Send size={19} className={sending ? "animate-pulse" : ""} />
        </button>
      </form>

      <p className="mt-2 px-1 text-[11px] text-[#C2956E]">
        Enter to send · Shift + Enter for a new line · Files up to 25 MB
      </p>
    </div>
  );
};

export default MessageInput;
