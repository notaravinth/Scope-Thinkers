import { Download, File, FileText, Image as ImageIcon } from "lucide-react";

const MessageList = ({ messages = [], currentUserId }) => {
  const formatTime = (timestamp) => {
    if (!timestamp) return "";

    const date = new Date(timestamp);

    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
  };

  const formatFileSize = (bytes = 0) => {
    if (bytes < 1024) return `${bytes} B`;

    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;

    const mb = kb / 1024;
    return `${mb.toFixed(1)} MB`;
  };

  const isImage = (message) =>
    message.type === "image" ||
    message.attachment?.mimeType?.startsWith("image/");

  if (messages.length === 0) {
    return (
      <div className="flex flex-1 items-center justify-center overflow-y-auto px-6">
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#E5D1B8]/5 text-xl">
            💬
          </div>

          <h3 className="text-sm font-semibold text-[#E5D1B8]">
            No messages yet
          </h3>

          <p className="mt-1 text-xs text-[#C2956E]">
            Send the first message.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-6 py-6">
      <div className="mx-auto flex max-w-4xl flex-col gap-3">
        {messages.map((message, index) => {
          const isMine = message.senderId === currentUserId;
          const imageMessage = isImage(message);
          const attachment = message.attachment;

          return (
            <div
              key={
                message.id ||
                `${message.chatId}-${message.createdAt}-${index}`
              }
              className={`flex w-full ${
                isMine ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`flex max-w-[70%] flex-col ${
                  isMine ? "items-end" : "items-start"
                }`}
              >
                {imageMessage && attachment?.url ? (
                  <div
                    className={`overflow-hidden rounded-2xl border border-[#C2956E]/30 ${
                      isMine ? "rounded-br-md" : "rounded-bl-md"
                    }`}
                  >
                    <a
                      href={attachment.url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <img
                        src={attachment.url}
                        alt={attachment.name || "Shared image"}
                        className="max-h-[360px] max-w-[360px] object-cover transition hover:opacity-90"
                      />
                    </a>
                  </div>
                ) : message.type === "file" && attachment?.url ? (
                  <a
                    href={attachment.url}
                    target="_blank"
                    rel="noreferrer"
                    download={attachment.name}
                    className={`flex min-w-[240px] items-center gap-3 rounded-2xl border border-[#C2956E]/30 px-4 py-3 transition hover:border-[#DD8E58] ${
                      isMine
                        ? "rounded-br-md bg-[#DD8E58] text-[#2B2129]"
                        : "rounded-bl-md bg-[#708A81] text-[#E5D1B8]"
                    }`}
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#2B2129]/20">
                      {attachment.mimeType === "application/pdf" ? (
                        <FileText size={19} />
                      ) : (
                        <File size={19} />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">
                        {attachment.name || "Shared file"}
                      </p>
                      <p className="mt-1 text-[11px] opacity-70">
                        {formatFileSize(attachment.size)}
                      </p>
                    </div>

                    <Download size={17} className="shrink-0" />
                  </a>
                ) : (
                  <div
                    className={`break-words rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      isMine
                        ? "rounded-br-md bg-[#DD8E58] text-[#2B2129]"
                        : "rounded-bl-md bg-[#708A81] text-[#E5D1B8]"
                    }`}
                  >
                    {message.content}
                  </div>
                )}

                {message.content && attachment && (
                  <div
                    className={`mt-2 break-words rounded-xl px-3 py-2 text-sm ${
                      isMine
                        ? "bg-[#DD8E58] text-[#2B2129]"
                        : "bg-[#708A81] text-[#E5D1B8]"
                    }`}
                  >
                    {message.content}
                  </div>
                )}

                <div className="mt-1 px-1 text-[10px] text-[#C2956E]">
                  {formatTime(message.createdAt)}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MessageList;
