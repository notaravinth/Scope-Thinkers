import { WebSocketServer } from "ws";

import { adminAuth, adminDb } from "./firebaseAdmin.js";

const PORT = 8080;

const wss = new WebSocketServer({
  port: PORT,
});

const connectedUsers = new Map();

const sendToSocket = (socket, data) => {
  if (socket.readyState === 1) {
    socket.send(JSON.stringify(data));
  }
};

const sendToUser = (userId, data) => {
  const socket = connectedUsers.get(userId);

  if (!socket) return;

  sendToSocket(socket, data);
};

const serializeTimestamp = (value) => {
  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate().toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (typeof value === "string") {
    return value;
  }

  return null;
};

const buildMessage = (document) => {
  const data = document.data();

  return {
    id: document.id,
    chatId: data.chatId,
    senderId: data.senderId,
    receiverId: data.receiverId,
    type: data.type || "text",
    content: data.content || "",
    status: data.status || "sent",
    attachment: data.attachment || null,
    createdAt: serializeTimestamp(data.createdAt),
  };
};

wss.on("connection", (socket) => {
  console.log("New WebSocket connection");

  socket.on("message", async (rawMessage) => {
    try {
      const rawText = rawMessage.toString();

      if (!rawText.trim()) return;

      let data;

      try {
        data = JSON.parse(rawText);
      } catch {
        sendToSocket(socket, {
          type: "error",
          message: "Invalid JSON message.",
        });
        return;
      }

      if (data.type === "authenticate") {
        const token = data.token;

        if (!token) {
          sendToSocket(socket, {
            type: "error",
            message: "Authentication token missing.",
          });
          socket.close();
          return;
        }

        try {
          const decodedToken = await adminAuth.verifyIdToken(token);
          const userId = decodedToken.uid;

          socket.userId = userId;
          connectedUsers.set(userId, socket);

          console.log(`User connected: ${userId}`);

          sendToSocket(socket, {
            type: "authenticated",
            userId,
          });
        } catch (error) {
          console.error("Firebase authentication error:", error);

          sendToSocket(socket, {
            type: "error",
            message:
              error?.message ||
              "Firebase authentication failed.",
          });

          socket.close();
        }

        return;
      }

      if (!socket.userId) {
        sendToSocket(socket, {
          type: "error",
          message:
            "WebSocket connection is not authenticated.",
        });
        return;
      }

      if (data.type === "send_message") {
        await handleSendMessage(socket, data);
        return;
      }

      if (data.type === "get_messages") {
        await handleGetMessages(socket, data);
        return;
      }

      sendToSocket(socket, {
        type: "error",
        message: "Unknown WebSocket event.",
      });
    } catch (error) {
      console.error("WEBSOCKET HANDLER ERROR:", error);

      sendToSocket(socket, {
        type: "error",
        message:
          error?.message ||
          "Something went wrong on the WebSocket server.",
      });
    }
  });

  socket.on("close", () => {
    if (!socket.userId) return;

    const currentSocket = connectedUsers.get(socket.userId);

    if (currentSocket === socket) {
      connectedUsers.delete(socket.userId);
    }

    console.log(`User disconnected: ${socket.userId}`);
  });

  socket.on("error", (error) => {
    console.error("WebSocket socket error:", error);
  });
});

const handleSendMessage = async (socket, data) => {
  const {
    chatId,
    receiverId,
    content,
    messageType,
    attachment,
  } = data;

  const senderId = socket.userId;

  if (!chatId || !receiverId) {
    sendToSocket(socket, {
      type: "error",
      message: "Chat and receiver are required.",
    });
    return;
  }

  const type = messageType || "text";
  const trimmedContent = typeof content === "string" ? content.trim() : "";

  if (type === "text" && !trimmedContent) {
    sendToSocket(socket, {
      type: "error",
      message: "Message content is required.",
    });
    return;
  }

  if (type !== "text" && !attachment?.url) {
    sendToSocket(socket, {
      type: "error",
      message: "Attachment information is required.",
    });
    return;
  }

  const chatRef = adminDb.collection("chatter_chats").doc(chatId);
  const chatSnapshot = await chatRef.get();

  if (!chatSnapshot.exists) {
    sendToSocket(socket, {
      type: "error",
      message: "Chat does not exist.",
    });
    return;
  }

  const chat = chatSnapshot.data();

  if (!Array.isArray(chat.participants)) {
    sendToSocket(socket, {
      type: "error",
      message: "Chat participants are invalid.",
    });
    return;
  }

  if (
    !chat.participants.includes(senderId) ||
    !chat.participants.includes(receiverId)
  ) {
    sendToSocket(socket, {
      type: "error",
      message: "You are not a participant in this chat.",
    });
    return;
  }

  if (type !== "text") {
    const allowedTypes = ["image", "file"];

    if (!allowedTypes.includes(type)) {
      sendToSocket(socket, {
        type: "error",
        message: "Unsupported attachment type.",
      });
      return;
    }

    if (
      typeof attachment.url !== "string" ||
      typeof attachment.name !== "string" ||
      typeof attachment.mimeType !== "string"
    ) {
      sendToSocket(socket, {
        type: "error",
        message: "Invalid attachment metadata.",
      });
      return;
    }

    if (
      !Number.isFinite(attachment.size) ||
      attachment.size <= 0 ||
      attachment.size > 25 * 1024 * 1024
    ) {
      sendToSocket(socket, {
        type: "error",
        message: "Attachment size is invalid.",
      });
      return;
    }
  }

  const createdAt = new Date();

  const messageData = {
    chatId,
    senderId,
    receiverId,
    type,
    content: trimmedContent,
    status: "sent",
    createdAt,
  };

  if (type !== "text") {
    messageData.attachment = {
      url: attachment.url,
      name: attachment.name,
      size: attachment.size,
      mimeType: attachment.mimeType,
      storagePath: attachment.storagePath || null,
    };
  }

  const messageRef = await adminDb
    .collection("chatter_messages")
    .add(messageData);

  let lastMessage = trimmedContent;

  if (type === "image") {
    lastMessage = trimmedContent
      ? `📷 ${trimmedContent}`
      : "📷 Photo";
  }

  if (type === "file") {
    lastMessage = trimmedContent
      ? `📎 ${trimmedContent}`
      : `📎 ${attachment.name}`;
  }

  await chatRef.update({
    lastMessage,
    lastMessageAt: createdAt,
  });

  const message = {
    id: messageRef.id,
    ...messageData,
    createdAt: createdAt.toISOString(),
  };

  sendToSocket(socket, {
    type: "message_sent",
    message,
  });

  sendToUser(receiverId, {
    type: "new_message",
    message,
  });

  console.log(
    `Message sent: ${senderId} -> ${receiverId} (${type})`,
  );
};

const handleGetMessages = async (socket, data) => {
  const { chatId } = data;
  const userId = socket.userId;

  if (!chatId) {
    sendToSocket(socket, {
      type: "error",
      message: "Chat ID is required.",
    });
    return;
  }

  const chatRef = adminDb.collection("chatter_chats").doc(chatId);

  try {
    const chatSnapshot = await chatRef.get();

    if (!chatSnapshot.exists) {
      sendToSocket(socket, {
        type: "error",
        chatId,
        message: "Chat does not exist.",
      });
      return;
    }

    const chat = chatSnapshot.data();

    if (!Array.isArray(chat.participants)) {
      sendToSocket(socket, {
        type: "error",
        chatId,
        message: "Chat participants are invalid.",
      });
      return;
    }

    if (!chat.participants.includes(userId)) {
      sendToSocket(socket, {
        type: "error",
        chatId,
        message: "You are not a participant in this chat.",
      });
      return;
    }

    const messagesSnapshot = await adminDb
      .collection("chatter_messages")
      .where("chatId", "==", chatId)
      .get();

    const messages = messagesSnapshot.docs
      .map(buildMessage)
      .sort((a, b) => {
        const aTime = a.createdAt
          ? new Date(a.createdAt).getTime()
          : 0;
        const bTime = b.createdAt
          ? new Date(b.createdAt).getTime()
          : 0;

        return aTime - bTime;
      });

    sendToSocket(socket, {
      type: "messages_history",
      chatId,
      messages,
    });

    console.log(`Loaded ${messages.length} messages for ${chatId}.`);
  } catch (error) {
    console.error("FAILED TO READ MESSAGES:", error);

    sendToSocket(socket, {
      type: "error",
      chatId,
      message: `Failed to read messages: ${error.message}`,
    });
  }
};

console.log(`WebSocket server running on ws://localhost:${PORT}`);
